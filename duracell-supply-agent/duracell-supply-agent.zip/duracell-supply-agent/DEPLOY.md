# Phase 8 — Deploying your agent

Two ways to get this online. Pick based on your goal.

---

## Option A — The easy way: Streamlit Community Cloud (free, recommended first)

Best for: getting a **live, shareable link** you can show in the interview, fast.
No Docker, no AWS, no credit card.

**Steps:**
1. Put this project on **GitHub** (a free public or private repo).
   - Make sure `.env` is NOT uploaded — it's in `.gitignore`, so it won't be.
2. Go to **share.streamlit.io** and sign in with GitHub.
3. Click **New app**, pick your repo, and set the main file to `app.py`.
4. Under **Advanced settings → Secrets**, paste your key like this:
   ```
   ANTHROPIC_API_KEY = "your-key-here"
   ```
   (This is how the server gets your key safely, instead of the `.env` file.)
5. Click **Deploy**. In a minute you get a public URL.

Now every time you `git push`, Streamlit redeploys automatically — that's CD in action.

> **Interview gold:** "Here's a live link to the agent I built" is far stronger
> than describing it. Deploy this and put the URL on your resume.

---

## Option B — The enterprise way: Docker + a cloud server (what the video does)

Best for: understanding how real companies deploy, and talking about it credibly.
This matches the Krish Naik project's AWS EC2 approach.

**The idea:**
1. **Docker** packs the app into a portable image (recipe is in `Dockerfile`):
   ```
   docker build -t duracell-agent .
   docker run -p 8501:8501 --env-file .env duracell-agent
   ```
   That runs your app in a container on your own machine first, to prove the box works.
2. **Push the image** to a registry (Docker Hub, AWS ECR).
3. **Run it on a cloud server** (AWS EC2, or any VM). The server pulls the image
   and runs the same `docker run` command. Because it's the same box, it behaves
   exactly like it did on your laptop.
4. **GitHub Actions** (`.github/workflows/ci.yml`) automates the checks on every
   push; a deploy job would then rebuild and restart the container on the server.

**Keys stay secret:** on a server you never upload `.env`. You store the API key
as a **GitHub secret** or a server environment variable. Committing secrets to
GitHub is the #1 rookie mistake — don't.

---

## What's already set up for you

- **`Dockerfile`** — the recipe to containerize the app.
- **`.github/workflows/ci.yml`** — runs automatically on every push to GitHub and
  checks the project still builds and the tools still work (this is CI, and it
  works for anyone with no extra setup).

## Say this in the interview
> "I containerized the app with Docker so it runs the same anywhere, and set up a
> GitHub Actions pipeline that tests the build on every push. For hosting I used
> Streamlit Cloud for a quick live version, and I understand the Docker-to-cloud-
> server path for a production setup. I'd follow your team's standards for the
> real deployment."
