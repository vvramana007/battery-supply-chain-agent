# Duracell Battery Supply Chain AI Agent

A learning project that mirrors a real **Forward Deployed Engineer (FDE)** project,
built in Duracell's world: an AI agent that answers questions about battery
inventory, orders, and shipments.

You build it one phase at a time. By the end you will be able to say, truthfully,
in an interview: *"I built an end-to-end AI agent on supply-chain data, with
secure data access, a UI, and automated deployment."*

---

## What you need (one-time setup)

1. Install **Python 3.10 or newer** (you have it if `python --version` works).
2. Open a terminal **inside this folder**.
3. Create a virtual environment (a clean, isolated box for this project's tools):

   ```
   python -m venv venv
   ```

   Turn it on:
   - Mac/Linux:  `source venv/bin/activate`
   - Windows:    `venv\Scripts\activate`

4. Install the tools:

   ```
   pip install -r requirements.txt
   ```

---

## Phase 1 — The data and the database  (DO THIS FIRST)

Run:

```
python setup_database.py
```

This creates:
- CSV files in the **`data/`** folder (open them — this is your "business data").
- A database file **`duracell.db`** (this is what the AI will later ask questions against).

**Your job in Phase 1:** open the CSV files, and read `setup_database.py` top to
bottom. Every line has a comment. If you understand this file, you understand the
foundation of the whole project.

A `duracell.db` is already included so you can start exploring immediately, but
run the script yourself at least once — that's the point.

---

## The 8 phases (the full roadmap)

| Phase | You build | Main concept you learn |
|------|-----------|------------------------|
| 1 | Data + SQLite database | SQL, data modeling |
| 2 | Business case + problem framing | Thinking like an FDE |
| 3 | Knowledge ingestion (RAG on the SOP doc) | RAG, embeddings |
| 4 | Data security + roles | Permission-aware data access |
| 5 | Agent tools (Python functions) | Tool use / function calling |
| 6 | The agent brain (LangGraph) | Agent orchestration |
| 7 | Streamlit UI + audit log | UX, adoption, logging |
| 8 | Deploy (GitHub Actions + cloud) | CI/CD, production |

See the full interactive roadmap (the artifact Claude made) for what each phase
teaches and which interview panelist it impresses.

---

## Folder layout

```
duracell-supply-agent/
  setup_database.py     <- Phase 1 (run this)
  duracell.db           <- the database (created by the script)
  requirements.txt      <- the tools to install
  .env.example          <- where your Claude API key will go later
  data/                 <- your CSV data files
  docs/                 <- the SOP document (used in Phase 3 for RAG)
  db/                   <- (reserved for later phases)
```

Built step by step with Claude. Take it one phase at a time — understanding beats speed.
