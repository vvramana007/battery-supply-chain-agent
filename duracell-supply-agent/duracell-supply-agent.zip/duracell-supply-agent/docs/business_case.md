# Business Case — Battery Supply Chain AI Agent

*Phase 2 deliverable. A one-page "why build this?" written the way a Forward*
*Deployed Engineer would pitch it to stakeholders. Figures come from the project's*
*own sample database (duracell.db), so the logic is concrete, not hand-waved.*

---

## 1. The problem

Supply-chain planners can't easily see which battery products are about to run
out or which shipments are slipping. The data exists — it's spread across
inventory, orders, and shipment tables — but getting an answer means someone
writing SQL by hand or pulling several reports and stitching them together.
By the time a stockout is noticed, it's often too late to avoid it.

## 2. Who feels it

- **Supply-chain planners** (Brian's team): do manual, repetitive report-pulling.
- **Account managers:** get surprised by late shipments to big retailers.
- **Customers (Walmart, Costco, Home Depot):** experience out-of-stocks.
- **The data team** (Patrick's): fields constant one-off "can you pull…" requests.

## 3. The cost of doing nothing

Measured on our sample data (one snapshot):

- **15 of 70** inventory positions (~21%) are already **below reorder point** —
  each one a potential out-of-stock across every product line.
- **55 of 328** shipments (~17%) are **delayed**, the worst by **10 days** — these
  are the escalations that erode retailer trust.
- **~$230,000** of open orders are in a Processing / In-Transit / Delayed state at
  any given moment — revenue exposed to fulfillment problems.

The hidden cost is **time**: a planner answering these questions by hand might
spend 30–60 minutes per question, several times a day.

## 4. The solution (one sentence)

An AI agent that lets any planner ask, in plain English — *"Which products are at
risk of running out, and which customers are affected?"* — and get an instant,
accurate answer grounded in the live database and company SOPs, with the numbers
to back it up.

## 5. The value

- **Speed:** a 30–60 minute manual lookup becomes a 10-second question.
- **Early warning:** flags stockout risk *before* it becomes an out-of-stock.
- **Fewer interruptions:** the data team stops fielding one-off report requests.
- **Trust:** every answer is grounded in real data and cites its source, so people
  can rely on it.
- **Rough ROI:** if it saves each of ~10 planners even 3 hours/week, that's ~1,500
  hours/year returned to higher-value work — before counting avoided stockouts.

## 6. How we'll know it worked (success metrics)

- **Adoption:** number of planners using it weekly (target: most of the team).
- **Questions answered per week** (usage = value).
- **Time-to-answer:** minutes → seconds.
- **Stockouts caught early:** count of at-risk items flagged before they hit zero.
- **Accuracy:** % of answers correct and properly cited (checked in Phase 3's eval).

---

### Why this matters for the role
A Forward Deployed Engineer is trusted when they start from business value, not
technology. This page is the proof that the project solves a real, quantified
problem — which is exactly how Duracell says it picks "high-value opportunities."
